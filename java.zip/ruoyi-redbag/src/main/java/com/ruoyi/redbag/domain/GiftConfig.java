package com.ruoyi.redbag.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 奖品配置对象 gift_config
 * 
 * @author andy
 * @date 2021-07-22
 */
public class GiftConfig extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编号 */
    private Long giftId;

    /** 奖品名称 */
    @Excel(name = "奖品名称")
    private String giftName;

    /** 图片地址 */
    @Excel(name = "图片地址")
    private String imgurl;

    /** 奖品数量 */
    @Excel(name = "奖品数量")
    private Long giftMember;

    /** 获奖人数 */
    @Excel(name = "获奖人数")
    private Long giftCount;

    /** 等级名称 */
    @Excel(name = "等级名称")
    private String name;

    public void setGiftId(Long giftId) 
    {
        this.giftId = giftId;
    }

    public Long getGiftId() 
    {
        return giftId;
    }
    public void setGiftName(String giftName) 
    {
        this.giftName = giftName;
    }

    public String getGiftName() 
    {
        return giftName;
    }
    public void setImgurl(String imgurl) 
    {
        this.imgurl = imgurl;
    }

    public String getImgurl() 
    {
        return imgurl;
    }
    public void setGiftMember(Long giftMember) 
    {
        this.giftMember = giftMember;
    }

    public Long getGiftMember() 
    {
        return giftMember;
    }
    public void setGiftCount(Long giftCount) 
    {
        this.giftCount = giftCount;
    }

    public Long getGiftCount() 
    {
        return giftCount;
    }
    public void setName(String name) 
    {
        this.name = name;
    }

    public String getName() 
    {
        return name;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("giftId", getGiftId())
            .append("giftName", getGiftName())
            .append("imgurl", getImgurl())
            .append("giftMember", getGiftMember())
            .append("giftCount", getGiftCount())
            .append("name", getName())
            .toString();
    }
}
