package com.ruoyi.redbag.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.redbag.domain.GiftLog;
import com.ruoyi.redbag.service.IGiftLogService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * IP抽奖记录Controller
 * 
 * @author ruoyi
 * @date 2021-07-22
 */
@Controller
@RequestMapping("/redbag/log")
public class GiftLogController extends BaseController
{
    private String prefix = "redbag/log";

    @Autowired
    private IGiftLogService giftLogService;

    @RequiresPermissions("redbag:log:view")
    @GetMapping()
    public String log()
    {
        return prefix + "/log";
    }

    /**
     * 查询IP抽奖记录列表
     */
    @RequiresPermissions("redbag:log:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(GiftLog giftLog)
    {
        startPage();
        List<GiftLog> list = giftLogService.selectGiftLogList(giftLog);
        return getDataTable(list);
    }

    /**
     * 导出IP抽奖记录列表
     */
    @RequiresPermissions("redbag:log:export")
    @Log(title = "IP抽奖记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(GiftLog giftLog)
    {
        List<GiftLog> list = giftLogService.selectGiftLogList(giftLog);
        ExcelUtil<GiftLog> util = new ExcelUtil<GiftLog>(GiftLog.class);
        return util.exportExcel(list, "IP抽奖记录数据");
    }

    /**
     * 新增IP抽奖记录
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存IP抽奖记录
     */
    @RequiresPermissions("redbag:log:add")
    @Log(title = "IP抽奖记录", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(GiftLog giftLog)
    {
        return toAjax(giftLogService.insertGiftLog(giftLog));
    }

    /**
     * 修改IP抽奖记录
     */
    @GetMapping("/edit/{logId}")
    public String edit(@PathVariable("logId") Long logId, ModelMap mmap)
    {
        GiftLog giftLog = giftLogService.selectGiftLogById(logId);
        mmap.put("giftLog", giftLog);
        return prefix + "/edit";
    }

    /**
     * 修改保存IP抽奖记录
     */
    @RequiresPermissions("redbag:log:edit")
    @Log(title = "IP抽奖记录", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(GiftLog giftLog)
    {
        return toAjax(giftLogService.updateGiftLog(giftLog));
    }

    /**
     * 删除IP抽奖记录
     */
    @RequiresPermissions("redbag:log:remove")
    @Log(title = "IP抽奖记录", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(giftLogService.deleteGiftLogByIds(ids));
    }
}
