package com.ruoyi.redbag.controller;

import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.redbag.domain.GiftConfig;
import com.ruoyi.redbag.domain.GiftLog;
import com.ruoyi.redbag.domain.GiftMember;
import com.ruoyi.redbag.service.IGiftConfigService;
import com.ruoyi.redbag.service.IGiftLogService;
import com.ruoyi.redbag.service.IGiftMemberService;
import com.ruoyi.redbag.utils.IpUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/redbag/api")
public class ApiController {

    @Autowired
    private IGiftConfigService configService;

    @Autowired
    private IGiftMemberService memberService;

    @Autowired
    private IGiftLogService giftLogService;

    @ResponseBody
    @GetMapping("/getConfigList")
    public AjaxResult getConfigList(GiftConfig gift) {
        List<GiftConfig> giftConfigs = configService.selectGiftConfigList(gift);
        for (int i = 0; i < giftConfigs.size(); i++) {
            GiftConfig config = giftConfigs.get(i);
            GiftMember member = new GiftMember();
            member.setGiftLv(config.getGiftId().toString());
            List<GiftMember> members = memberService.selectGiftMemberList(member, 0);
            if (members.size() < config.getGiftCount()) {
                config.setGiftCount(0L);
                giftConfigs.set(i, config);
            }
        }
        return AjaxResult.success(giftConfigs);
    }

    @ResponseBody
    @GetMapping("/getMemberListByGiftId")
    public AjaxResult getMemberListByGiftId(GiftMember gift, HttpServletRequest req) {
        String id = IpUtil.getRequestIp(req);
        GiftLog logFind = new GiftLog();
        logFind.setIp(id);
        List<GiftLog> logList = giftLogService.selectGiftLogList(logFind);
        // 奖品数量
        List<GiftConfig> figts = configService.selectGiftConfigAll();

        List<GiftMember> userList;
        if (gift.getGiftLv() != null) {
            if (logList.size() >= figts.size()) {
                return AjaxResult.warn(String.format("本轮抽奖机会【%s】次已经用完！", logList.size()));
            }

            GiftConfig config = configService.selectGiftConfigById(Long.parseLong(gift.getGiftLv()));
            userList = memberService.selectGiftMemberList(gift, Integer.parseInt(config.getGiftCount().toString()));
        } else {
            userList = memberService.selectGiftMemberList(gift, 0);
        }
        return AjaxResult.success(userList);
    }

    @ResponseBody
    @PostMapping("/saveIp")
    public AjaxResult saveIp(HttpServletRequest req) {
        GiftLog logFind = new GiftLog();
        String id = IpUtil.getRequestIp(req);
        logFind.setIp(id);
        List<GiftLog> logList = giftLogService.selectGiftLogList(logFind);
        // 奖品数量
        List<GiftConfig> figts = configService.selectGiftConfigAll();
        if (logList.size() >= figts.size()) {
            return AjaxResult.warn(String.format("本轮抽奖机会【%s】次已经用完！", logList.size()));
        }
        logFind.setIpCount(1L);
        giftLogService.insertGiftLog(logFind);
        return AjaxResult.success(logFind);
    }

    @ResponseBody
    @GetMapping("/butIsEnable")
    public AjaxResult butIsEnable(HttpServletRequest req) {
        List<GiftConfig> figts = configService.selectGiftConfigAll();
        // 抽奖次数
        GiftLog logFind = new GiftLog();
        String id = IpUtil.getRequestIp(req);
        logFind.setIp(id);
        List<GiftLog> logList = giftLogService.selectGiftLogList(logFind);
        // 对比是否可用
        if (logList.size() >= figts.size()) {
            return AjaxResult.warn(String.format("本轮抽奖机会【%s】次已经用完！", figts.size()));
        } else {
            return AjaxResult.success("ok");
        }

    }
}
