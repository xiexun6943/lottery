package com.ruoyi.redbag.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * IP抽奖记录对象 gift_log
 * 
 * @author ruoyi
 * @date 2021-07-22
 */
public class GiftLog extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编号 */
    private Long logId;

    /** ip地址 */
    @Excel(name = "ip地址")
    private String ip;

    /** ip抽奖次数 */
    @Excel(name = "ip抽奖次数")
    private Long ipCount;

    /** 编辑时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "编辑时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date editTime;

    public void setLogId(Long logId) 
    {
        this.logId = logId;
    }

    public Long getLogId() 
    {
        return logId;
    }
    public void setIp(String ip) 
    {
        this.ip = ip;
    }

    public String getIp() 
    {
        return ip;
    }
    public void setIpCount(Long ipCount) 
    {
        this.ipCount = ipCount;
    }

    public Long getIpCount() 
    {
        return ipCount;
    }
    public void setEditTime(Date editTime) 
    {
        this.editTime = editTime;
    }

    public Date getEditTime() 
    {
        return editTime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("logId", getLogId())
            .append("ip", getIp())
            .append("ipCount", getIpCount())
            .append("createTime", getCreateTime())
            .append("editTime", getEditTime())
            .toString();
    }
}
