package com.ruoyi.redbag.mapper;

import java.util.List;
import com.ruoyi.redbag.domain.GiftConfig;

/**
 * 奖品配置Mapper接口
 * 
 * @author andy
 * @date 2021-07-22
 */
public interface GiftConfigMapper 
{
    /**
     * 查询奖品配置
     * 
     * @param giftId 奖品配置ID
     * @return 奖品配置
     */
    public GiftConfig selectGiftConfigById(Long giftId);

    /**
     * 查询奖品配置列表
     * 
     * @param giftConfig 奖品配置
     * @return 奖品配置集合
     */
    public List<GiftConfig> selectGiftConfigList(GiftConfig giftConfig);

    public List<GiftConfig> selectGiftConfigAll();

    /**
     * 新增奖品配置
     * 
     * @param giftConfig 奖品配置
     * @return 结果
     */
    public int insertGiftConfig(GiftConfig giftConfig);

    /**
     * 修改奖品配置
     * 
     * @param giftConfig 奖品配置
     * @return 结果
     */
    public int updateGiftConfig(GiftConfig giftConfig);

    /**
     * 删除奖品配置
     * 
     * @param giftId 奖品配置ID
     * @return 结果
     */
    public int deleteGiftConfigById(Long giftId);

    /**
     * 批量删除奖品配置
     * 
     * @param giftIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteGiftConfigByIds(String[] giftIds);
}
