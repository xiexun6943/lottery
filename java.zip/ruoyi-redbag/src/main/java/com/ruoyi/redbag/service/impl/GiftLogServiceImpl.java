package com.ruoyi.redbag.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.redbag.mapper.GiftLogMapper;
import com.ruoyi.redbag.domain.GiftLog;
import com.ruoyi.redbag.service.IGiftLogService;
import com.ruoyi.common.core.text.Convert;

/**
 * IP抽奖记录Service业务层处理
 * 
 * @author ruoyi
 * @date 2021-07-22
 */
@Service
public class GiftLogServiceImpl implements IGiftLogService 
{
    @Autowired
    private GiftLogMapper giftLogMapper;

    /**
     * 查询IP抽奖记录
     * 
     * @param logId IP抽奖记录ID
     * @return IP抽奖记录
     */
    @Override
    public GiftLog selectGiftLogById(Long logId)
    {
        return giftLogMapper.selectGiftLogById(logId);
    }

    /**
     * 查询IP抽奖记录列表
     * 
     * @param giftLog IP抽奖记录
     * @return IP抽奖记录
     */
    @Override
    public List<GiftLog> selectGiftLogList(GiftLog giftLog)
    {
        return giftLogMapper.selectGiftLogList(giftLog);
    }

    /**
     * 新增IP抽奖记录
     * 
     * @param giftLog IP抽奖记录
     * @return 结果
     */
    @Override
    public int insertGiftLog(GiftLog giftLog)
    {
        giftLog.setCreateTime(DateUtils.getNowDate());
        return giftLogMapper.insertGiftLog(giftLog);
    }

    /**
     * 修改IP抽奖记录
     * 
     * @param giftLog IP抽奖记录
     * @return 结果
     */
    @Override
    public int updateGiftLog(GiftLog giftLog)
    {
        return giftLogMapper.updateGiftLog(giftLog);
    }

    /**
     * 删除IP抽奖记录对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteGiftLogByIds(String ids)
    {
        return giftLogMapper.deleteGiftLogByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除IP抽奖记录信息
     * 
     * @param logId IP抽奖记录ID
     * @return 结果
     */
    @Override
    public int deleteGiftLogById(Long logId)
    {
        return giftLogMapper.deleteGiftLogById(logId);
    }
}
