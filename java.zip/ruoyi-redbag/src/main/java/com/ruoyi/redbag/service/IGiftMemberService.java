package com.ruoyi.redbag.service;

import java.util.List;
import com.ruoyi.redbag.domain.GiftMember;

/**
 * 抽奖人员管理Service接口
 * 
 * @author ruoyi
 * @date 2021-07-22
 */
public interface IGiftMemberService 
{
    /**
     * 查询抽奖人员管理
     * 
     * @param memberId 抽奖人员管理ID
     * @return 抽奖人员管理
     */
    public GiftMember selectGiftMemberById(String memberId);

    /**
     * 查询抽奖人员管理列表
     * 
     * @param giftMember 抽奖人员管理
     * @return 抽奖人员管理集合
     */
    public List<GiftMember> selectGiftMemberList(GiftMember giftMember, int count);

    /**
     * 新增抽奖人员管理
     * 
     * @param giftMember 抽奖人员管理
     * @return 结果
     */
    public int insertGiftMember(GiftMember giftMember);

    /**
     * 修改抽奖人员管理
     * 
     * @param giftMember 抽奖人员管理
     * @return 结果
     */
    public int updateGiftMember(GiftMember giftMember);

    /**
     * 批量删除抽奖人员管理
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteGiftMemberByIds(String ids);

    /**
     * 删除抽奖人员管理信息
     * 
     * @param memberId 抽奖人员管理ID
     * @return 结果
     */
    public int deleteGiftMemberById(String memberId);
}
