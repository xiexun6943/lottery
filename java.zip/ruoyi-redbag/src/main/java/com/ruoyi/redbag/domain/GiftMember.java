package com.ruoyi.redbag.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 抽奖人员管理对象 gift_member
 * 
 * @author ruoyi
 * @date 2021-07-22
 */
public class GiftMember extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编号 */
    private String memberId;

    /** 姓名 */
    @Excel(name = "姓名")
    private String memberName;

    /** 奖品级别 */
    @Excel(name = "奖品级别")
    private String giftLv;

    /** 是否可见（参与抽奖） */
    @Excel(name = "是否可见", readConverterExp = "参=与抽奖")
    private String isVisible;

    /** 创建人 */
    @Excel(name = "创建人")
    private String creator;

    /** 修改人 */
    @Excel(name = "修改人")
    private String editor;

    /** 修改时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date editTime;

    /** 是否中奖 */
    @Excel(name = "是否中奖")
    private String isEnable;

    /** 昵称 */
    @Excel(name = "昵称")
    private String nickname;

    public void setMemberId(String memberId) 
    {
        this.memberId = memberId;
    }

    public String getMemberId() 
    {
        return memberId;
    }
    public void setMemberName(String memberName) 
    {
        this.memberName = memberName;
    }

    public String getMemberName() 
    {
        return memberName;
    }
    public void setGiftLv(String giftLv) 
    {
        this.giftLv = giftLv;
    }

    public String getGiftLv() 
    {
        return giftLv;
    }
    public void setIsVisible(String isVisible) 
    {
        this.isVisible = isVisible;
    }

    public String getIsVisible() 
    {
        return isVisible;
    }
    public void setCreator(String creator) 
    {
        this.creator = creator;
    }

    public String getCreator() 
    {
        return creator;
    }
    public void setEditor(String editor) 
    {
        this.editor = editor;
    }

    public String getEditor() 
    {
        return editor;
    }
    public void setEditTime(Date editTime) 
    {
        this.editTime = editTime;
    }

    public Date getEditTime() 
    {
        return editTime;
    }
    public void setIsEnable(String isEnable) 
    {
        this.isEnable = isEnable;
    }

    public String getIsEnable() 
    {
        return isEnable;
    }
    public void setNickname(String nickname) 
    {
        this.nickname = nickname;
    }

    public String getNickname() 
    {
        return nickname;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("memberId", getMemberId())
            .append("memberName", getMemberName())
            .append("giftLv", getGiftLv())
            .append("isVisible", getIsVisible())
            .append("creator", getCreator())
            .append("editor", getEditor())
            .append("createTime", getCreateTime())
            .append("editTime", getEditTime())
            .append("isEnable", getIsEnable())
            .append("nickname", getNickname())
            .toString();
    }
}
