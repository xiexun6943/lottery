package com.ruoyi.redbag.mapper;

import java.util.List;
import com.ruoyi.redbag.domain.GiftLog;

/**
 * IP抽奖记录Mapper接口
 * 
 * @author ruoyi
 * @date 2021-07-22
 */
public interface GiftLogMapper 
{
    /**
     * 查询IP抽奖记录
     * 
     * @param logId IP抽奖记录ID
     * @return IP抽奖记录
     */
    public GiftLog selectGiftLogById(Long logId);

    /**
     * 查询IP抽奖记录列表
     * 
     * @param giftLog IP抽奖记录
     * @return IP抽奖记录集合
     */
    public List<GiftLog> selectGiftLogList(GiftLog giftLog);

    /**
     * 新增IP抽奖记录
     * 
     * @param giftLog IP抽奖记录
     * @return 结果
     */
    public int insertGiftLog(GiftLog giftLog);

    /**
     * 修改IP抽奖记录
     * 
     * @param giftLog IP抽奖记录
     * @return 结果
     */
    public int updateGiftLog(GiftLog giftLog);

    /**
     * 删除IP抽奖记录
     * 
     * @param logId IP抽奖记录ID
     * @return 结果
     */
    public int deleteGiftLogById(Long logId);

    /**
     * 批量删除IP抽奖记录
     * 
     * @param logIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteGiftLogByIds(String[] logIds);
}
