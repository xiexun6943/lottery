package com.ruoyi.redbag.mapper;

import java.util.List;
import com.ruoyi.redbag.domain.GiftMember;
import org.apache.ibatis.annotations.Param;

/**
 * 抽奖人员管理Mapper接口
 * 
 * @author ruoyi
 * @date 2021-07-22
 */
public interface GiftMemberMapper 
{
    /**
     * 查询抽奖人员管理
     * 
     * @param memberId 抽奖人员管理ID
     * @return 抽奖人员管理
     */
    public GiftMember selectGiftMemberById(String memberId);

    /**
     * 查询抽奖人员管理列表
     * 
     * @param giftMember 抽奖人员管理
     * @return 抽奖人员管理集合
     */
    public List<GiftMember> selectGiftMemberList( @Param("GiftMember")GiftMember GiftMember, @Param("count")int count);

    /**
     * 新增抽奖人员管理
     * 
     * @param giftMember 抽奖人员管理
     * @return 结果
     */
    public int insertGiftMember(GiftMember giftMember);

    /**
     * 修改抽奖人员管理
     * 
     * @param giftMember 抽奖人员管理
     * @return 结果
     */
    public int updateGiftMember(GiftMember giftMember);

    /**
     * 删除抽奖人员管理
     * 
     * @param memberId 抽奖人员管理ID
     * @return 结果
     */
    public int deleteGiftMemberById(String memberId);

    /**
     * 批量删除抽奖人员管理
     * 
     * @param memberIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteGiftMemberByIds(String[] memberIds);
}
