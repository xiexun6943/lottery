package com.ruoyi.redbag.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.redbag.mapper.GiftMemberMapper;
import com.ruoyi.redbag.domain.GiftMember;
import com.ruoyi.redbag.service.IGiftMemberService;
import com.ruoyi.common.core.text.Convert;

/**
 * 抽奖人员管理Service业务层处理
 * 
 * @author ruoyi
 * @date 2021-07-22
 */
@Service
public class GiftMemberServiceImpl implements IGiftMemberService 
{
    @Autowired
    private GiftMemberMapper giftMemberMapper;

    /**
     * 查询抽奖人员管理
     * 
     * @param memberId 抽奖人员管理ID
     * @return 抽奖人员管理
     */
    @Override
    public GiftMember selectGiftMemberById(String memberId)
    {
        return giftMemberMapper.selectGiftMemberById(memberId);
    }

    /**
     * 查询抽奖人员管理列表
     * 
     * @param giftMember 抽奖人员管理
     * @return 抽奖人员管理
     */
    @Override
    public List<GiftMember> selectGiftMemberList(GiftMember giftMember, int count)
    {
        return giftMemberMapper.selectGiftMemberList(giftMember, count);
    }

    /**
     * 新增抽奖人员管理
     * 
     * @param giftMember 抽奖人员管理
     * @return 结果
     */
    @Override
    public int insertGiftMember(GiftMember giftMember)
    {
        giftMember.setCreateTime(DateUtils.getNowDate());
        return giftMemberMapper.insertGiftMember(giftMember);
    }

    /**
     * 修改抽奖人员管理
     * 
     * @param giftMember 抽奖人员管理
     * @return 结果
     */
    @Override
    public int updateGiftMember(GiftMember giftMember)
    {
        return giftMemberMapper.updateGiftMember(giftMember);
    }

    /**
     * 删除抽奖人员管理对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteGiftMemberByIds(String ids)
    {
        return giftMemberMapper.deleteGiftMemberByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除抽奖人员管理信息
     * 
     * @param memberId 抽奖人员管理ID
     * @return 结果
     */
    @Override
    public int deleteGiftMemberById(String memberId)
    {
        return giftMemberMapper.deleteGiftMemberById(memberId);
    }
}
