package com.ruoyi.redbag.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.redbag.mapper.GiftConfigMapper;
import com.ruoyi.redbag.domain.GiftConfig;
import com.ruoyi.redbag.service.IGiftConfigService;
import com.ruoyi.common.core.text.Convert;

/**
 * 奖品配置Service业务层处理
 * 
 * @author andy
 * @date 2021-07-22
 */
@Service
public class GiftConfigServiceImpl implements IGiftConfigService 
{
    @Autowired
    private GiftConfigMapper giftConfigMapper;

    /**
     * 查询奖品配置
     * 
     * @param giftId 奖品配置ID
     * @return 奖品配置
     */
    @Override
    public GiftConfig selectGiftConfigById(Long giftId)
    {
        return giftConfigMapper.selectGiftConfigById(giftId);
    }

    /**
     * 查询奖品配置列表
     * 
     * @param giftConfig 奖品配置
     * @return 奖品配置
     */
    @Override
    public List<GiftConfig> selectGiftConfigList(GiftConfig giftConfig)
    {
        return giftConfigMapper.selectGiftConfigList(giftConfig);
    }
    @Override
    public List<GiftConfig> selectGiftConfigAll()
    {
        return giftConfigMapper.selectGiftConfigAll();
    }

    /**
     * 新增奖品配置
     * 
     * @param giftConfig 奖品配置
     * @return 结果
     */
    @Override
    public int insertGiftConfig(GiftConfig giftConfig)
    {
        return giftConfigMapper.insertGiftConfig(giftConfig);
    }

    /**
     * 修改奖品配置
     * 
     * @param giftConfig 奖品配置
     * @return 结果
     */
    @Override
    public int updateGiftConfig(GiftConfig giftConfig)
    {
        return giftConfigMapper.updateGiftConfig(giftConfig);
    }

    /**
     * 删除奖品配置对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteGiftConfigByIds(String ids)
    {
        return giftConfigMapper.deleteGiftConfigByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除奖品配置信息
     * 
     * @param giftId 奖品配置ID
     * @return 结果
     */
    @Override
    public int deleteGiftConfigById(Long giftId)
    {
        return giftConfigMapper.deleteGiftConfigById(giftId);
    }
}
