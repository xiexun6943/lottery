package com.ruoyi.redbag.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.redbag.domain.GiftConfig;
import com.ruoyi.redbag.service.IGiftConfigService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 奖品配置Controller
 * 
 * @author andy
 * @date 2021-07-22
 */
@Controller
@RequestMapping("/redbag/config")
public class GiftConfigController extends BaseController
{
    private String prefix = "redbag/config";

    @Autowired
    private IGiftConfigService giftConfigService;

    @RequiresPermissions("redbag:config:view")
    @GetMapping()
    public String config()
    {
        return prefix + "/config";
    }

    /**
     * 查询奖品配置列表
     */
    @RequiresPermissions("redbag:config:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(GiftConfig giftConfig)
    {
        startPage();
        List<GiftConfig> list = giftConfigService.selectGiftConfigList(giftConfig);
        return getDataTable(list);
    }

    /**
     * 导出奖品配置列表
     */
    @RequiresPermissions("redbag:config:export")
    @Log(title = "奖品配置", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(GiftConfig giftConfig)
    {
        List<GiftConfig> list = giftConfigService.selectGiftConfigList(giftConfig);
        ExcelUtil<GiftConfig> util = new ExcelUtil<GiftConfig>(GiftConfig.class);
        return util.exportExcel(list, "奖品配置数据");
    }

    /**
     * 新增奖品配置
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存奖品配置
     */
    @RequiresPermissions("redbag:config:add")
    @Log(title = "奖品配置", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(GiftConfig giftConfig)
    {
        return toAjax(giftConfigService.insertGiftConfig(giftConfig));
    }

    /**
     * 修改奖品配置
     */
    @GetMapping("/edit/{giftId}")
    public String edit(@PathVariable("giftId") Long giftId, ModelMap mmap)
    {
        GiftConfig giftConfig = giftConfigService.selectGiftConfigById(giftId);
        mmap.put("giftConfig", giftConfig);
        return prefix + "/edit";
    }

    /**
     * 修改保存奖品配置
     */
    @RequiresPermissions("redbag:config:edit")
    @Log(title = "奖品配置", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(GiftConfig giftConfig)
    {
        return toAjax(giftConfigService.updateGiftConfig(giftConfig));
    }

    /**
     * 删除奖品配置
     */
    @RequiresPermissions("redbag:config:remove")
    @Log(title = "奖品配置", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(giftConfigService.deleteGiftConfigByIds(ids));
    }
}
