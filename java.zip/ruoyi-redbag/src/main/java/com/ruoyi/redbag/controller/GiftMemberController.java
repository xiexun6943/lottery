package com.ruoyi.redbag.controller;

import java.util.List;
import java.util.UUID;

import com.ruoyi.redbag.domain.GiftConfig;
import com.ruoyi.redbag.service.IGiftConfigService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.redbag.domain.GiftMember;
import com.ruoyi.redbag.service.IGiftMemberService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 抽奖人员管理Controller
 *
 * @author ruoyi
 * @date 2021-07-22
 */
@Controller
@RequestMapping("/redbag/member")
public class GiftMemberController extends BaseController {
    private String prefix = "redbag/member";

    @Autowired
    private IGiftMemberService giftMemberService;

    @Autowired
    private IGiftConfigService giftConfigService;

    @RequiresPermissions("redbag:member:view")
    @GetMapping()
    public String member(ModelMap mmap) {

        List<GiftConfig> configs = giftConfigService.selectGiftConfigAll();
        mmap.put("configs", configs);
        return prefix + "/member";
    }

    /**
     * 查询抽奖人员管理列表
     */
    @RequiresPermissions("redbag:member:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(GiftMember giftMember) {
        startPage();
        List<GiftMember> list = giftMemberService.selectGiftMemberList(giftMember, 0);
        for (int i = 0; i < list.size(); i++) {
            GiftMember obj = list.get(i);
            String lv = obj.getGiftLv();
            GiftConfig gc = giftConfigService.selectGiftConfigById(Long.parseLong(lv));
            obj.setGiftLv(gc==null?lv:gc.getGiftName());
            list.set(i, obj);
        }
        return getDataTable(list);
    }

    /**
     * 导出抽奖人员管理列表
     */
    @RequiresPermissions("redbag:member:export")
    @Log(title = "抽奖人员管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(GiftMember giftMember) {
        List<GiftMember> list = giftMemberService.selectGiftMemberList(giftMember, 0);
        ExcelUtil<GiftMember> util = new ExcelUtil<GiftMember>(GiftMember.class);
        return util.exportExcel(list, "抽奖人员管理数据");
    }

    /**
     * 新增抽奖人员管理
     */
    @GetMapping("/add")
    public String add(ModelMap mmap) {
        List<GiftConfig> configs = giftConfigService.selectGiftConfigAll();
        mmap.put("configs", configs);
        return prefix + "/add";
    }

    /**
     * 新增保存抽奖人员管理
     */
    @RequiresPermissions("redbag:member:add")
    @Log(title = "抽奖人员管理", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(GiftMember giftMember) {
        String uuid = UUID.randomUUID().toString().replaceAll("-", "");
        giftMember.setMemberId(uuid);
        return toAjax(giftMemberService.insertGiftMember(giftMember));
    }

    /**
     * 修改抽奖人员管理
     */
    @GetMapping("/edit/{memberId}")
    public String edit(@PathVariable("memberId") String memberId, ModelMap mmap) {
        GiftMember giftMember = giftMemberService.selectGiftMemberById(memberId);
        mmap.put("giftMember", giftMember);
        List<GiftConfig> configs = giftConfigService.selectGiftConfigAll();
        mmap.put("configs", configs);
        return prefix + "/edit";
    }

    /**
     * 修改保存抽奖人员管理
     */
    @RequiresPermissions("redbag:member:edit")
    @Log(title = "抽奖人员管理", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(GiftMember giftMember) {
        return toAjax(giftMemberService.updateGiftMember(giftMember));
    }

    /**
     * 删除抽奖人员管理
     */
    @RequiresPermissions("redbag:member:remove")
    @Log(title = "抽奖人员管理", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(giftMemberService.deleteGiftMemberByIds(ids));
    }
}
